export async function POST(req: Request) {
  // Placeholder: paywall disabled
  return new Response("ok", { status: 200 });
}
