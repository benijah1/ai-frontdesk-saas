export default function HomePage() {
  return (
    <div className="space-y-8">
      <section className="text-center mt-10">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Your AI Front Desk for Any Business</h1>
        <p className="text-lg text-gray-600 mt-4">
          Convert calls, chats, and web visits into booked jobs. White‑label tenant theming, CRM, and Stripe billing ready.
        </p>
        <div className="mt-6 flex justify-center gap-4">
          <a className="btn" href="/sign-up">Start Free</a>
          <a className="link" href="/sign-in">I already have an account</a>
        </div>
      </section>
      <section className="grid md:grid-cols-3 gap-6">
        <div className="card">
          <h3 className="font-semibold text-xl mb-2">Multi‑tenant</h3>
          <p className="text-gray-600">Each customer has their own theme, keys, and subdomain.</p>
        </div>
        <div className="card">
          <h3 className="font-semibold text-xl mb-2">AI Front Desk</h3>
          <p className="text-gray-600">Chat + voice endpoints wired for your business data.</p>
        </div>
        <div className="card">
          <h3 className="font-semibold text-xl mb-2">Billing‑ready</h3>
          <p className="text-gray-600">Stripe stubs in place. Paywall disabled for testing.</p>
        </div>
      </section>
    </div>
  );
}
